//
//  ViewController.h
//  QREncoderDemo
//
//  Created by qianfeng on 13-4-7.
//  Copyright (c) 2013年 PK. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "QRCodeGenerator.h"

@interface ViewController : UIViewController

@end
