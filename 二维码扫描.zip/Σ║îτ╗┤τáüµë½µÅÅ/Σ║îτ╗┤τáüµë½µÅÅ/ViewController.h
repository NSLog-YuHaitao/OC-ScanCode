//
//  ViewController.h
//  二维码扫描
//
//  Created by 刘硕 on 16-1-25.
//  Copyright (c) 2016年 北京千锋互联科技有限公司. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

